<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <script>document.write(new Date().getFullYear())</script> © Coding Task
            </div>
            <div class="col-md-6">
                <div class="text-md-end footer-links d-none d-md-block">
                  
                </div>
            </div>
        </div>
    </div>
</footer>